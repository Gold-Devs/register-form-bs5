<?php
mysqli_connect('localhost','root','', 'forumseries') or  die('cant connect database ');
//mysqli_select_db("forumseries") or die('cannot select database');
?> 